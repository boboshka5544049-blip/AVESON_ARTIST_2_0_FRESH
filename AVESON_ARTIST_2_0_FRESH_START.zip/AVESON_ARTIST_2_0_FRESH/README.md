# AVESON ARTIST 2.0
Fresh Android Java project. No V12 dependency.
